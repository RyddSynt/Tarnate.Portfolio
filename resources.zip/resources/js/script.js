document.addEventListener('DOMContentLoaded', function() {
    const text = document.getElementById('text-2');

    const textLoad = () => {
        setTimeout(() => {
            text.textContent = "Portfolio";
        }, 0);
        setTimeout(() => {
            text.textContent = "Checkout";
        }, 4000);
        setTimeout(() => {
            text.textContent = "Everyone";
        }, 8000);
    }

    textLoad();
    setInterval(textLoad, 12000);
});



//DON'T EDIT THIS























console.log("Credits to encoder");
console.log("BERNAL");
console.log("THIS IS PAID TEMPLATE");

document.addEventListener('DOMContentLoaded', function() {
    const licencingElement = document.getElementById('licencing');
    const bodyElement = document.body;

    if (licencingElement.innerHTML.trim() !== '') {
        licencingElement.innerHTML = 'License by Bernal';
    }

    licencingElement.contentEditable = false;

    if (licencingElement.innerHTML.trim() === 'Bernal') {
        licencingElement.contentEditable = false;
    }

    licencingElement.addEventListener('input', function() {
        if (licencingElement.innerHTML.trim() !== 'License by Bernal') {
            licencingElement.innerHTML = 'License by Bernal';
            licencingElement.contentEditable = false;
        }
    });
});

