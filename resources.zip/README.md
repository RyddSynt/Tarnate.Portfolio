### Dynamic Portfolio For CIT 18

```

```
